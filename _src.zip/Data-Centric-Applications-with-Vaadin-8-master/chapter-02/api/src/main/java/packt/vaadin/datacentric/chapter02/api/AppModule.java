package packt.vaadin.datacentric.chapter02.api;

/**
 * @author Alejandro Duarte
 */
public interface AppModule {
    void register(ApplicationLayout layout);
}
