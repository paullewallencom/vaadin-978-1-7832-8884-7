package packt.vaadin.datacentric.chapter09.domain;

/**
 * @author Alejandro Duarte
 */
public enum Status {

    RECEIVED, MISSED

}
