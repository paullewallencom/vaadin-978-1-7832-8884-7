package packt.vaadin.datacentric.chapter08.domain;

/**
 * @author Alejandro Duarte
 */
public enum Status {

    RECEIVED, MISSED

}
