package packt.vaadin.datacentric.chapter08.reports;

import lombok.Data;

/**
 * @author Alejandro Duarte
 */
@Data
public class CapacityDto {

    private String monthName;

    private int calls;

}
