package packt.vaadin.datacentric.chapter08.domain;

/**
 * @author Alejandro Duarte
 */
public enum City {

    BOGOTA, TURKU, LONDON, BERLIN, HELSINKI, TOKYO, SAN_FRANCISCO, SIDNEY, LAGOS, VANCOUVER, SANTIAGO, BEIJING

}
